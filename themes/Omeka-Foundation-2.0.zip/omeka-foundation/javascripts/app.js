jQuery(document).ready(function($){
	
	// add foundation classes 
	$("ul#sort-links-list").addClass("sub-nav");
	$(".item-pagination").addClass("pagination");
	$("#primary-nav").addClass("nav"); 
	
	$(":submit").addClass("button");
	$("#submit_search_advanced").addClass("button small");
	$("#advanced-search-form").addClass("custom large-6 small-6");
	$(".add_search").addClass("tiny button dropdown");
	$(".remove_search").addClass("tiny button secondary");
	
});